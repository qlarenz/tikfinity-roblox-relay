const express = require('express');
const app = express();
app.use(express.json());

// Set this to a long random string. Use the SAME value in:
//  - the TikFinity webhook URL (?token=...)
//  - your Roblox script's SECRET_TOKEN
const SECRET_TOKEN = process.env.SECRET_TOKEN || "CHANGE_ME";

const MAX_EVENTS = 200; // how many recent events to keep in memory

let events = [];
let nextId = 1;

// TikFinity's exact webhook JSON shape isn't publicly documented and can vary
// by event type. This tries the most common field names/paths. After you fire
// a test event from TikFinity's Event Simulator, check this server's logs
// (they print the raw payload) and add/adjust a line below if needed.
//
// This version reads the COMMENT TEXT itself (what the viewer typed), not the
// commenter's TikTok handle, because the game expects viewers to type a
// Roblox username into TikTok chat. Only the first word is used, and it's
// checked against Roblox's username character rules before being accepted.
function extractRobloxUsername(body) {
  const raw =
    body.comment ||
    body.message ||
    body.text ||
    body.data?.comment ||
    body.data?.message ||
    body.data?.text ||
    null;

  if (!raw) return null;

  const firstWord = String(raw).trim().split(/\s+/)[0];
  const looksLikeRobloxUsername = /^[A-Za-z0-9_]{3,20}$/.test(firstWord);
  return looksLikeRobloxUsername ? firstWord : null;
}

app.post('/tikfinity-webhook', (req, res) => {
  const token = req.query.token;
  if (token !== SECRET_TOKEN) {
    return res.status(403).json({ error: 'invalid token' });
  }

  console.log('Incoming TikFinity payload:', JSON.stringify(req.body));

  const username = extractRobloxUsername(req.body);
  if (!username) {
    console.warn('No valid Roblox username found in the comment — inspect the payload above and update extractRobloxUsername() in server.js if the comment text lives in a different field');
    return res.status(200).json({ ok: true, note: 'no valid username found in comment' });
  }

  events.push({ id: nextId++, username, receivedAt: Date.now() });
  if (events.length > MAX_EVENTS) {
    events = events.slice(events.length - MAX_EVENTS);
  }

  res.status(200).json({ ok: true });
});

// Roblox polls this endpoint. Returns only events newer than `since`.
app.get('/events', (req, res) => {
  const token = req.query.token;
  if (token !== SECRET_TOKEN) {
    return res.status(403).json({ error: 'invalid token' });
  }

  const since = parseInt(req.query.since, 10) || 0;
  const newEvents = events.filter(e => e.id > since);
  res.json({
    events: newEvents,
    latestId: events.length ? events[events.length - 1].id : since,
  });
});

app.get('/', (req, res) => {
  res.send('TikFinity -> Roblox relay is running.');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Relay listening on port ${PORT}`));
