# TikFinity → Roblox Relay

Viewers type a Roblox username in your TikTok LIVE chat. Your Roblox game checks
if that player is currently in the server and spotlights the camera on them —
or, if they haven't joined yet, spawns a placeholder character with that name.

## How it fits together

TikTok LIVE comment (a Roblox username) → TikFinity (your @username) → webhook →
this relay (public URL) → Roblox polls the relay → spotlights the matching
player, or spawns a placeholder NPC if they're not in the server

Roblox game servers run in Roblox's cloud, so they can't reach TikFinity's local
Event API directly. This relay is the public middleman both sides can talk to.

The relay reads the **comment text itself** (what the viewer typed), not the
commenter's TikTok handle — only the first word is used, and it's checked
against Roblox's username character rules (3–20 letters/numbers/underscores)
before being passed along.

## 1. Deploy this folder

Any free Node.js host works (Render, Railway, Glitch, Cyclic, Fly.io). General steps for Render:

1. Push this folder to a GitHub repo (or use Render's "Deploy from folder" if offered).
2. Create a new **Web Service** on render.com, point it at the repo.
3. Build command: `npm install` — Start command: `npm start`.
4. Add an environment variable `SECRET_TOKEN` set to a long random string you make up.
5. Deploy. You'll get a public URL like `https://your-app.onrender.com`.

## 2. Point TikFinity at it

1. In TikFinity (browser), go to **Setup** → enter your TikTok @handle → **Connect to TikTok LIVE**.
2. Go to **Actions & Events** → create a new **Event**: trigger = **Comment** (who can trigger: everyone).
3. Create an **Action** for that event: check **Fire a webhook**, and set the URL to:
   `https://your-app.onrender.com/tikfinity-webhook?token=YOUR_SECRET_TOKEN`
4. Save, then use the **Event Simulator** at the bottom of the Actions & Events page to fire a test comment.

## 3. Check the payload once

Open your host's logs (e.g. Render's Logs tab) right after firing the test comment.
You'll see a line like `Incoming TikFinity payload: {...}` — that's the real JSON shape
TikFinity sends. If `extractUsername()` in `server.js` didn't find a name (you'll see a
warning), open `server.js`, look at the logged JSON, and add the correct field path to
the list in `extractUsername()`, then redeploy.

## 4. Roblox side

In Studio, two scripts handle this:

- `TikFinitySpawner` (`ServerScriptService`) — polls the relay, checks if a
  player with the typed name is in the server, and fires the `CameraSpotlight`
  RemoteEvent (in `ReplicatedStorage`) at either that player's position or a
  freshly spawned placeholder NPC's position.
- `CameraSpotlightHandler` (`StarterPlayerScripts`) — on every client, tweens
  the camera to briefly frame whatever position it's told, then hands control
  back to the normal player camera.

Setup:

1. **Game Settings → Security → Allow HTTP Requests** must be ON, or `HttpService` calls will fail.
2. Open `TikFinitySpawner` and set:
   - `RELAY_URL` to your deployed URL (no trailing slash)
   - `SECRET_TOKEN` to the same string you set on the relay
   - `SPAWN_POSITION` to wherever you want placeholder NPCs to appear
3. Test with Play mode (ideally with a second test account/player in the server
   so you can see the "real player found" path), then fire a test comment from
   TikFinity's Event Simulator containing just a Roblox username, e.g. `Builderman`.
4. Go live and connect TikFinity to your real stream.

## Notes / next steps

- Right now NPCs are simple blocks with a name tag (no dependency on external assets).
  Swap the body in `spawnNPC()` for a real character model/rig once this works end to end.
- Add a per-user cooldown in the relay or script if you don't want the same viewer
  spawning repeatedly within a few seconds.
- The relay stores events in memory only — it resets if the host restarts. Fine for
  a live stream session; swap in a small database if you need persistence.
